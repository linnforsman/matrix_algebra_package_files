from setuptools import setup

setup(name='matrix-alg-basic',
      version='0.1',
      description='Basic Matrix Algebra Operation',
      packages=['matrix-alg-basic'],
      author= 'Linn Forsman',
      author_email = 'linnforsman@protonmail.com',
      zip_safe=False)

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/